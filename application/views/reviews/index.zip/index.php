<!DOCTYPE html>
<html>

<head>
    <title>Review Table</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url('application/assets/css/custome.css') ?>" type="text/css" rel="stylesheet">
    <link href="<?php echo site_url(); ?>application/assets/css/seaff.css" type="text/css" rel="stylesheet">
    <link rel='stylesheet' href='//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css'>
    <link rel='stylesheet' href='https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css'>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
    <script type="text/javascript">
         ShopifyApp.init({
            apiKey: '<?php echo $api_key; ?>',
            shopOrigin: '<?php echo 'https://'  . $shop;  ?>'
        });
    </script>
    <script type="text/javascript">
        ShopifyApp.ready(function() {
            ShopifyApp.Bar.initialize({
                buttons: {
                    primary: {
                        label: 'Save',
                        message: 'unicorn_form_submit',
                        loading: true
                    }
                }
            });
        });
    </script>
    <style>
        .dataTables_filter,
        .dataTables_info {
            display: none;
        }
    </style>
</head>

<body>
    <section class="bg-white py-3 ">
        <div class="container">
            <div class="row justify-content-end">
                <div class="col-2 text-right">
                    <a href="<?php echo base_url(); ?>index.php/reviews/index" class="btn btn-warning"> Reviews </a>
                </div>
                <div class="col-2">
                    <a href="<?php echo base_url(); ?>index.php/setting" class="btn btn-info"><i class="fa fa-cog"></i> Setting</a>
                </div>
            </div>
        </div>
    </section>
    <div class="wrapper">
        <!-- <section class="my-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-12">
                            <h1>Reviews</h1>
                        </div>
                        <div class="col-12">
                            <div class="row">
                                <a href="" class="btn btn-info btn-sm mr-3">
                                    <i class="fa fa-download"></i> Import reviews
                                </a>
                                <a href="" class="btn btn-primary btn-sm">
                                    <i class="fa fa-arrow-up"></i> Export reviews
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <section class="">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h3>Review</h3>
                    </div>
                    <div class="col-md-12">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="btn nav-link active" id="all-reviews-btn" data-toggle="tab" href="#all-reviews" data-url="<?php echo base_url() . 'index.php/reviews/all-reviews' ?>" role="tab" aria-controls="all-reviews" aria-selected="true">All Reviews</a>
                            </li>
                            <li class="nav-item">
                                <a class="btn nav-link" id="unpublished-btn" data-toggle="tab" href="#all-reviews" data-url="<?php echo base_url() . 'index.php/reviews/state/unpublished' ?>" role="tab" aria-controls="all-reviews" aria-selected="true">Unpublished</a>
                            </li>
                            <li class="nav-item">
                                <a class="btn nav-link" id="published-btn" data-toggle="tab" href="#all-reviews" data-url="<?php echo base_url() . 'index.php/reviews/state/published' ?>" role="tab" aria-controls="all-reviews" aria-selected="true">Published</a>
                            </li>
                            <li class="nav-item">
                                <a class="btn nav-link" id="flagged-btn" data-toggle="tab" href="#all-reviews" data-url="<?php echo base_url() . 'index.php/reviews/state/flagged' ?>" role="tab" aria-controls="all-reviews" aria-selected="true">Flagged</a>
                            </li>
                            <li class="nav-item ml-auto">
                                <form action="" method="get">
                                    <div class="form-group m-0">
                                        <input type="text" class="form-control m-0" placeholder="Search for reviews..." aria-label="Search" id="search">
                                    </div>
                                </form>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="all-reviews" role="tabpanel" aria-labelledby="home-tab">
                                <table class="table table-bordered table-striped table-responsive" id="all-review-table" width="100%">
                                    <div id="reload">
                                        <thead class="">
                                            <tr>
                                                <th>
                                                    <input type="checkbox" id="checkall" value='1'>
                                                    <button class="multi" data-url="<?php echo base_url() . 'index.php/Home/deleteReviewMultiple' ?>">Delete</button>
                                                    <button class="multi" data-url="<?php echo base_url() . 'index.php/Home/publishedReviewMultiple' ?>">Publish</button>
                                                    <button class="multi" data-url="<?php echo base_url() . 'index.php/Home/unpublishedReviewMultiple' ?>">Unpublish</button>
                                                    <button class="multi" data-url="<?php echo base_url() . 'index.php/Home/flaggedReviewMultiple' ?>">Flagged</button>
                                                    <!-- <input type="button" id="delete" value='Delete' class="btn-sm">-->
                                                </th>
                                                <th>Rating</th>
                                                <th style="width:30%">Review</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (isset($reviews)) {
                                            ?>
                                                <?php foreach ($reviews as $review) { ?>
                                                    <tr id='tr_<?= $review->id ?>'>
                                                        <td>
                                                        <input type="checkbox" class='checkbox' name='delete' value='<?php echo $review->id ?>' style="opacity:1">
                                                        </td>
                                                        <td>
                                                            <?php for ($i = 1; $i <= $review->rating; $i++) { ?>
                                                                <i class="fa fa-star"></i>
                                                            <?php } ?>
                                                        </td>
                                                        <td>
                                                            <a href=""><?php echo $review->review_title ?></a>
                                                            <p class="review-my-2">
                                                                <?php echo $review->body_of_review ?>
                                                            </p>
                                                            <span class="">– <?php echo $review->name ?> <a class="" href="">U.S. POLO ASSN.</a></span>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            $date = $review->created_at;
                                                            echo date('j F Y h:i:s A', strtotime(str_replace('-', '/', $date)));
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            if ($review->state == "published") {
                                                                echo '<span class="badge badge-success">' . $review->state . '</span>';
                                                            } else if ($review->state == "unpublished") {
                                                                echo '<span class="badge badge-danger">' . $review->state . '</span>';
                                                            } else if ($review->state == "flagged") {
                                                                echo '<span class="badge badge-warning"> ' . $review->state . '</span>';
                                                            }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            <?php }
                                            ?>
                                        </tbody>
                                    </div>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
        </section>

    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script>

    </script>
    <!-- <script src="<?php //echo base_url() 
                        ?>/application/assets/js/custome.js"></script> -->
    <script>
        $(document).ready(function() {
            $("#show_review_form").click(function() {
                $("#review_form").slideToggle();
            });
            /* 1. Visualizing things on Hover - See next part for action on click */
            $('#stars li').on('mouseover', function() {
                var onStar = parseInt($(this).data('value'), 10); // The star currently mouse on

                // Now highlight all the stars that's not after the current hovered star
                $(this).parent().children('li.star').each(function(e) {
                    if (e < onStar) {
                        $(this).addClass('hover');
                    } else {
                        $(this).removeClass('hover');
                    }
                });

            }).on('mouseout', function() {
                $(this).parent().children('li.star').each(function(e) {
                    $(this).removeClass('hover');
                });
            });


            /* 2. Action to perform on click */
            $('#stars li').on('click', function() {
                var onStar = parseInt($(this).data('value'), 10); // The star currently selected
                var stars = $(this).parent().children('li.star');

                for (i = 0; i < stars.length; i++) {
                    $(stars[i]).removeClass('selected');
                }

                for (i = 0; i < onStar; i++) {
                    $(stars[i]).addClass('selected');
                }

                // JUST RESPONSE (Not needed)
                var ratingValue = parseInt($('#stars li.selected').last().data('value'), 10);
                $('#rating').val(ratingValue);
                var msg = "";
                if (ratingValue > 1) {
                    msg = "Thanks! You rated this " + ratingValue + " stars.";
                } else {
                    msg = "We will improve ourselves. You rated this " + ratingValue + " stars.";
                }
                responseMessage(msg);

            });


            function responseMessage(msg) {
                $('.success-box').fadeIn(200);
                $('.success-box div.text-message').html("<span>" + msg + "</span>");
            }
            $(function() {
                $("#tabs").tabs({
                    beforeLoad: function(event, ui) {
                        ui.jqXHR.fail(function() {
                            ui.panel.html(
                                "Couldn't load this tab. We'll try to fix this as soon as possible. " +
                                "If this wouldn't be a demo.");
                        });
                    }
                });
            });
            $('#form').submit(function(e) {
                e.preventDefault();
                var product_id = $('#product_id').val();
                var name = $('#name').val();
                var email = $('#email').val();
                var rating = $('#rating').val();
                var review_title = $('#review_title').val();
                var body_of_review = $('#body_of_review').val();
                var html = '<p class="text-success">Thank you for submitting a review!</p>';
                $.ajax({
                    url: "<?php echo base_url() . 'index.php/review/store' ?>",
                    type: "POST",
                    dataType: "JSON",
                    error: function() {
                        alert('Something is wrong');
                    },
                    data: {
                        product_id: product_id,
                        name: name,
                        email: email,
                        rating: rating,
                        review_title: review_title,
                        body_of_review: body_of_review
                    },
                    success: function(data) {
                        $('#form').each(function() {
                            this.reset();
                        });
                        $('#review_form').html(html);
                        $('#show_review_form').hide();
                    }
                });
                return false;
            });


            //  $('#all-review-table').DataTable(function() {});
            var oTable = $('#all-review-table').DataTable({}); //pay attention to capital D, which is mandatory to retrieve "api" datatables' object, as @Lionel said
            $('#search').keyup(function() {
                oTable.search($(this).val()).draw();
            });


            $('.btn').on('click', function(e) {
                e.preventDefault();
                $.ajax({
                    type: 'ajax',
                    url: $(this).data('url'),
                    async: false,
                    dataType: 'json',
                    type: 'POST',
                    cache: false,
                    error: function() {
                        alert('Something is wrong');
                    },
                    success: function(data) {
                        console.log(data);
                        var html = '';
                        var i;
                        for (i = 0; i < data.length; i++) {
                            html += '<tr id="tr_'+ data[i].id + '">';
                            html += '<td>';
                            html += '<input type="checkbox" class="checkbox" name="delete" style="opacity:1" value="'+ data[i].id + '">';
                            html += '</td>';
                            html += '<td> ';
                            for (var j = 1; j <= data[i].rating; j++) {
                                html += '<i class="fa fa-star">' + '</i>';
                            }
                            html += '</td>';
                            html += '<td>';
                            html += '<a href="">';
                            html += data[i].review_title + '</a>';
                            html += '<p class="my-2">' + data[i].body_of_review + '</p>';
                            html += '<span class="">' + '– ' + data[i].name + ' ' + '<a class="" href="">' + 'U.S. POLO ASSN.' + '</a>' + '</span>'
                            html += '</td>';
                            html += '<td>';
                            html += data[i].created_at;
                            html += '</td>';
                            html += '<td>';
                            var status = data[i].state;
                            if (status == "published") {
                                html += '<span class="badge badge-success">' + data[i].state + '</span>';
                            } else if (status == "unpublished") {
                                html += '<span class="badge badge-danger">' + data[i].state + '</span>';
                            } else if (status == "flagged") {
                                html += '<span class="badge badge-warning">' + data[i].state + '</span>';
                            }
                            html += ' </td>';
                            html += '</tr>';
                        }
                        // console.log(html);
                        $('#all-review-table tbody').html(html);
                    }
                });
            });

            // Check all
            $("#checkall").change(function() {

                var checked = $(this).is(':checked');
                if (checked) {
                    $(".checkbox").each(function() {
                        $(this).prop("checked", true);
                    });
                } else {
                    $(".checkbox").each(function() {
                        $(this).prop("checked", false);
                    });
                }
            });

            // Changing state of CheckAll checkbox 
            $(".checkbox").click(function() {

                if ($(".checkbox").length == $(".checkbox:checked").length) {
                    $("#checkall").prop("checked", true);
                } else {
                    $("#checkall").prop("checked", false);
                }

            });
            $('.success').fadeOut(5000);
            // Delete button clicked
            $('.multi').click(function() {

                // Confirm alert
                var deleteConfirm = confirm("Are you sure?");
                if (deleteConfirm == true) {

                    // Get reviewid from checked checkboxes
                    var reviews_arr = [];
                    $(".checkbox:checked").each(function() {
                        var reviewid = $(this).val();

                        reviews_arr.push(reviewid);
                    });

                    // Array length
                    var length = reviews_arr.length;

                    if (length > 0) {

                        // AJAX request
                        $.ajax({
                            url: $(this).data('url'),
                            type: 'post',
                            data: {
                                review_ids: reviews_arr
                            },
                            success: function(response) {
                                window.location.reload('#all-review-table');  
                                toastr.success('Success', 'Updated the table');
                            },
                            error: function() {
                                toastr.danger('Warning', 'Something went wrong!');
                            }
                        });
                    } else {
                        toastr.warning('Warning', 'please select at least one row!!');
                        // alert('please select at least one row!')
                    }
                }

            });


        });
    </script>
</body>

</html>